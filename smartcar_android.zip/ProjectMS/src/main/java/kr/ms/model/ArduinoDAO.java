package kr.ms.model;

import java.util.List;

public interface ArduinoDAO {
    public List<ArduinoVO> arduinoList();
    public List<ArduinoVO> arduinoList2();
}
